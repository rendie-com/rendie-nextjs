export const self_config = {
  path: "view/Default/",
  pg_database: "verceldb",//postgres    verceldb
  TablePre: "rd_",
  isInstall: true,
};